#include <immintrin.h>
#include <stdint.h>


__attribute__((always_inline)) inline void  
hashjoin_i64_mem(const uint64_t *hash_t, const uint64_t hash_size, const uint64_t *id,  const uint64_t *val, const uint64_t in_size, const uint64_t batch_size, uint64_t *out_id, uint64_t &out_size)
{
uint64_t offset =  0;
const uint32_t r =  47;

const __m512i m_v = _mm512_set1_epi64(0xc6a4a7935bd1e995);
const int64_t m_s = 0xc6a4a7935bd1e995;
const __m512i h_v = _mm512_set1_epi64(0x8445d61a4e774912^(8*0xc6a4a7935bd1e995));
const int64_t h_s = 0x8445d61a4e774912^(8*0xc6a4a7935bd1e995);
const __m512i addr_mask_v = _mm512_set1_epi64(hash_size - 1);
const uint64_t addr_mask_s = hash_size - 1;
const uint64_t scale =  8;

__m512i kr_v0_p0;
__m512i kr_v1_p0;
__m512i kr_v0_p1;
__m512i kr_v1_p1;
__m512i kr_v0_p2;
__m512i kr_v1_p2;
__m512i kr_v0_p3;
__m512i kr_v1_p3;
__m512i kr_v0_p4;
__m512i kr_v1_p4;

__mmask8 mask_v0_p0;
__mmask8 mask_v1_p0;
__mmask8 mask_v0_p1;
__mmask8 mask_v1_p1;
__mmask8 mask_v0_p2;
__mmask8 mask_v1_p2;
__mmask8 mask_v0_p3;
__mmask8 mask_v1_p3;
__mmask8 mask_v0_p4;
__mmask8 mask_v1_p4;

__m512i data_v0_p0;
__m512i data_v1_p0;
__m512i data_v0_p1;
__m512i data_v1_p1;
__m512i data_v0_p2;
__m512i data_v1_p2;
__m512i data_v0_p3;
__m512i data_v1_p3;
__m512i data_v0_p4;
__m512i data_v1_p4;

__m512i k_v0_p0;
__m512i k_v1_p0;
__m512i k_v0_p1;
__m512i k_v1_p1;
__m512i k_v0_p2;
__m512i k_v1_p2;
__m512i k_v0_p3;
__m512i k_v1_p3;
__m512i k_v0_p4;
__m512i k_v1_p4;

__m512i dst_v0_p0;
__m512i dst_v1_p0;
__m512i dst_v0_p1;
__m512i dst_v1_p1;
__m512i dst_v0_p2;
__m512i dst_v1_p2;
__m512i dst_v0_p3;
__m512i dst_v1_p3;
__m512i dst_v0_p4;
__m512i dst_v1_p4;

__m512i addr_v0_p0;
__m512i addr_v1_p0;
__m512i addr_v0_p1;
__m512i addr_v1_p1;
__m512i addr_v0_p2;
__m512i addr_v1_p2;
__m512i addr_v0_p3;
__m512i addr_v1_p3;
__m512i addr_v0_p4;
__m512i addr_v1_p4;

__m512i vals_v0_p0;
__m512i vals_v1_p0;
__m512i vals_v0_p1;
__m512i vals_v1_p1;
__m512i vals_v0_p2;
__m512i vals_v1_p2;
__m512i vals_v0_p3;
__m512i vals_v1_p3;
__m512i vals_v0_p4;
__m512i vals_v1_p4;

__m512i hval_v0_p0;
__m512i hval_v1_p0;
__m512i hval_v0_p1;
__m512i hval_v1_p1;
__m512i hval_v0_p2;
__m512i hval_v1_p2;
__m512i hval_v0_p3;
__m512i hval_v1_p3;
__m512i hval_v0_p4;
__m512i hval_v1_p4;

__m512i ids_v0_p0;
__m512i ids_v1_p0;
__m512i ids_v0_p1;
__m512i ids_v1_p1;
__m512i ids_v0_p2;
__m512i ids_v1_p2;
__m512i ids_v0_p3;
__m512i ids_v1_p3;
__m512i ids_v0_p4;
__m512i ids_v1_p4;

for(uint64_t i = 0; i < in_size; i = i + batch_size)
{
data_v0_p0 = _mm512_loadu_epi64(val + offset + 0);
data_v1_p0 = _mm512_loadu_epi64(val + offset + 8);
data_v0_p1 = _mm512_loadu_epi64(val + offset + 16);
data_v1_p1 = _mm512_loadu_epi64(val + offset + 24);
data_v0_p2 = _mm512_loadu_epi64(val + offset + 32);
data_v1_p2 = _mm512_loadu_epi64(val + offset + 40);
data_v0_p3 = _mm512_loadu_epi64(val + offset + 48);
data_v1_p3 = _mm512_loadu_epi64(val + offset + 56);
data_v0_p4 = _mm512_loadu_epi64(val + offset + 64);
data_v1_p4 = _mm512_loadu_epi64(val + offset + 72);

k_v0_p0 = _mm512_mullo_epi64(data_v0_p0, m_v);
k_v1_p0 = _mm512_mullo_epi64(data_v1_p0, m_v);
k_v0_p1 = _mm512_mullo_epi64(data_v0_p1, m_v);
k_v1_p1 = _mm512_mullo_epi64(data_v1_p1, m_v);
k_v0_p2 = _mm512_mullo_epi64(data_v0_p2, m_v);
k_v1_p2 = _mm512_mullo_epi64(data_v1_p2, m_v);
k_v0_p3 = _mm512_mullo_epi64(data_v0_p3, m_v);
k_v1_p3 = _mm512_mullo_epi64(data_v1_p3, m_v);
k_v0_p4 = _mm512_mullo_epi64(data_v0_p4, m_v);
k_v1_p4 = _mm512_mullo_epi64(data_v1_p4, m_v);

kr_v0_p0 = _mm512_srli_epi64(k_v0_p0, r);
kr_v1_p0 = _mm512_srli_epi64(k_v1_p0, r);
kr_v0_p1 = _mm512_srli_epi64(k_v0_p1, r);
kr_v1_p1 = _mm512_srli_epi64(k_v1_p1, r);
kr_v0_p2 = _mm512_srli_epi64(k_v0_p2, r);
kr_v1_p2 = _mm512_srli_epi64(k_v1_p2, r);
kr_v0_p3 = _mm512_srli_epi64(k_v0_p3, r);
kr_v1_p3 = _mm512_srli_epi64(k_v1_p3, r);
kr_v0_p4 = _mm512_srli_epi64(k_v0_p4, r);
kr_v1_p4 = _mm512_srli_epi64(k_v1_p4, r);

kr_v0_p0 = _mm512_xor_epi64(kr_v0_p0, k_v0_p0);
kr_v1_p0 = _mm512_xor_epi64(kr_v1_p0, k_v1_p0);
kr_v0_p1 = _mm512_xor_epi64(kr_v0_p1, k_v0_p1);
kr_v1_p1 = _mm512_xor_epi64(kr_v1_p1, k_v1_p1);
kr_v0_p2 = _mm512_xor_epi64(kr_v0_p2, k_v0_p2);
kr_v1_p2 = _mm512_xor_epi64(kr_v1_p2, k_v1_p2);
kr_v0_p3 = _mm512_xor_epi64(kr_v0_p3, k_v0_p3);
kr_v1_p3 = _mm512_xor_epi64(kr_v1_p3, k_v1_p3);
kr_v0_p4 = _mm512_xor_epi64(kr_v0_p4, k_v0_p4);
kr_v1_p4 = _mm512_xor_epi64(kr_v1_p4, k_v1_p4);

kr_v0_p0 = _mm512_mullo_epi64(kr_v0_p0, m_v);
kr_v1_p0 = _mm512_mullo_epi64(kr_v1_p0, m_v);
kr_v0_p1 = _mm512_mullo_epi64(kr_v0_p1, m_v);
kr_v1_p1 = _mm512_mullo_epi64(kr_v1_p1, m_v);
kr_v0_p2 = _mm512_mullo_epi64(kr_v0_p2, m_v);
kr_v1_p2 = _mm512_mullo_epi64(kr_v1_p2, m_v);
kr_v0_p3 = _mm512_mullo_epi64(kr_v0_p3, m_v);
kr_v1_p3 = _mm512_mullo_epi64(kr_v1_p3, m_v);
kr_v0_p4 = _mm512_mullo_epi64(kr_v0_p4, m_v);
kr_v1_p4 = _mm512_mullo_epi64(kr_v1_p4, m_v);

hval_v0_p0 = _mm512_xor_epi64(h_v, kr_v0_p0);
hval_v1_p0 = _mm512_xor_epi64(h_v, kr_v1_p0);
hval_v0_p1 = _mm512_xor_epi64(h_v, kr_v0_p1);
hval_v1_p1 = _mm512_xor_epi64(h_v, kr_v1_p1);
hval_v0_p2 = _mm512_xor_epi64(h_v, kr_v0_p2);
hval_v1_p2 = _mm512_xor_epi64(h_v, kr_v1_p2);
hval_v0_p3 = _mm512_xor_epi64(h_v, kr_v0_p3);
hval_v1_p3 = _mm512_xor_epi64(h_v, kr_v1_p3);
hval_v0_p4 = _mm512_xor_epi64(h_v, kr_v0_p4);
hval_v1_p4 = _mm512_xor_epi64(h_v, kr_v1_p4);

hval_v0_p0 = _mm512_mullo_epi64(hval_v0_p0, m_v);
hval_v1_p0 = _mm512_mullo_epi64(hval_v1_p0, m_v);
hval_v0_p1 = _mm512_mullo_epi64(hval_v0_p1, m_v);
hval_v1_p1 = _mm512_mullo_epi64(hval_v1_p1, m_v);
hval_v0_p2 = _mm512_mullo_epi64(hval_v0_p2, m_v);
hval_v1_p2 = _mm512_mullo_epi64(hval_v1_p2, m_v);
hval_v0_p3 = _mm512_mullo_epi64(hval_v0_p3, m_v);
hval_v1_p3 = _mm512_mullo_epi64(hval_v1_p3, m_v);
hval_v0_p4 = _mm512_mullo_epi64(hval_v0_p4, m_v);
hval_v1_p4 = _mm512_mullo_epi64(hval_v1_p4, m_v);

kr_v0_p0 = _mm512_srli_epi64(hval_v0_p0, r);
kr_v1_p0 = _mm512_srli_epi64(hval_v1_p0, r);
kr_v0_p1 = _mm512_srli_epi64(hval_v0_p1, r);
kr_v1_p1 = _mm512_srli_epi64(hval_v1_p1, r);
kr_v0_p2 = _mm512_srli_epi64(hval_v0_p2, r);
kr_v1_p2 = _mm512_srli_epi64(hval_v1_p2, r);
kr_v0_p3 = _mm512_srli_epi64(hval_v0_p3, r);
kr_v1_p3 = _mm512_srli_epi64(hval_v1_p3, r);
kr_v0_p4 = _mm512_srli_epi64(hval_v0_p4, r);
kr_v1_p4 = _mm512_srli_epi64(hval_v1_p4, r);

hval_v0_p0 = _mm512_xor_epi64(hval_v0_p0, kr_v0_p0);
hval_v1_p0 = _mm512_xor_epi64(hval_v1_p0, kr_v1_p0);
hval_v0_p1 = _mm512_xor_epi64(hval_v0_p1, kr_v0_p1);
hval_v1_p1 = _mm512_xor_epi64(hval_v1_p1, kr_v1_p1);
hval_v0_p2 = _mm512_xor_epi64(hval_v0_p2, kr_v0_p2);
hval_v1_p2 = _mm512_xor_epi64(hval_v1_p2, kr_v1_p2);
hval_v0_p3 = _mm512_xor_epi64(hval_v0_p3, kr_v0_p3);
hval_v1_p3 = _mm512_xor_epi64(hval_v1_p3, kr_v1_p3);
hval_v0_p4 = _mm512_xor_epi64(hval_v0_p4, kr_v0_p4);
hval_v1_p4 = _mm512_xor_epi64(hval_v1_p4, kr_v1_p4);

hval_v0_p0 = _mm512_mullo_epi64(hval_v0_p0, m_v);
hval_v1_p0 = _mm512_mullo_epi64(hval_v1_p0, m_v);
hval_v0_p1 = _mm512_mullo_epi64(hval_v0_p1, m_v);
hval_v1_p1 = _mm512_mullo_epi64(hval_v1_p1, m_v);
hval_v0_p2 = _mm512_mullo_epi64(hval_v0_p2, m_v);
hval_v1_p2 = _mm512_mullo_epi64(hval_v1_p2, m_v);
hval_v0_p3 = _mm512_mullo_epi64(hval_v0_p3, m_v);
hval_v1_p3 = _mm512_mullo_epi64(hval_v1_p3, m_v);
hval_v0_p4 = _mm512_mullo_epi64(hval_v0_p4, m_v);
hval_v1_p4 = _mm512_mullo_epi64(hval_v1_p4, m_v);

kr_v0_p0 = _mm512_srli_epi64(hval_v0_p0, r);
kr_v1_p0 = _mm512_srli_epi64(hval_v1_p0, r);
kr_v0_p1 = _mm512_srli_epi64(hval_v0_p1, r);
kr_v1_p1 = _mm512_srli_epi64(hval_v1_p1, r);
kr_v0_p2 = _mm512_srli_epi64(hval_v0_p2, r);
kr_v1_p2 = _mm512_srli_epi64(hval_v1_p2, r);
kr_v0_p3 = _mm512_srli_epi64(hval_v0_p3, r);
kr_v1_p3 = _mm512_srli_epi64(hval_v1_p3, r);
kr_v0_p4 = _mm512_srli_epi64(hval_v0_p4, r);
kr_v1_p4 = _mm512_srli_epi64(hval_v1_p4, r);

dst_v0_p0 = _mm512_xor_epi64(hval_v0_p0, kr_v0_p0);
dst_v1_p0 = _mm512_xor_epi64(hval_v1_p0, kr_v1_p0);
dst_v0_p1 = _mm512_xor_epi64(hval_v0_p1, kr_v0_p1);
dst_v1_p1 = _mm512_xor_epi64(hval_v1_p1, kr_v1_p1);
dst_v0_p2 = _mm512_xor_epi64(hval_v0_p2, kr_v0_p2);
dst_v1_p2 = _mm512_xor_epi64(hval_v1_p2, kr_v1_p2);
dst_v0_p3 = _mm512_xor_epi64(hval_v0_p3, kr_v0_p3);
dst_v1_p3 = _mm512_xor_epi64(hval_v1_p3, kr_v1_p3);
dst_v0_p4 = _mm512_xor_epi64(hval_v0_p4, kr_v0_p4);
dst_v1_p4 = _mm512_xor_epi64(hval_v1_p4, kr_v1_p4);

addr_v0_p0 = _mm512_and_epi64(dst_v0_p0, addr_mask_v);
addr_v1_p0 = _mm512_and_epi64(dst_v1_p0, addr_mask_v);
addr_v0_p1 = _mm512_and_epi64(dst_v0_p1, addr_mask_v);
addr_v1_p1 = _mm512_and_epi64(dst_v1_p1, addr_mask_v);
addr_v0_p2 = _mm512_and_epi64(dst_v0_p2, addr_mask_v);
addr_v1_p2 = _mm512_and_epi64(dst_v1_p2, addr_mask_v);
addr_v0_p3 = _mm512_and_epi64(dst_v0_p3, addr_mask_v);
addr_v1_p3 = _mm512_and_epi64(dst_v1_p3, addr_mask_v);
addr_v0_p4 = _mm512_and_epi64(dst_v0_p4, addr_mask_v);
addr_v1_p4 = _mm512_and_epi64(dst_v1_p4, addr_mask_v);

vals_v0_p0 = _mm512_i64gather_epi64(addr_v0_p0, hash_t, scale);
vals_v1_p0 = _mm512_i64gather_epi64(addr_v1_p0, hash_t, scale);
vals_v0_p1 = _mm512_i64gather_epi64(addr_v0_p1, hash_t, scale);
vals_v1_p1 = _mm512_i64gather_epi64(addr_v1_p1, hash_t, scale);
vals_v0_p2 = _mm512_i64gather_epi64(addr_v0_p2, hash_t, scale);
vals_v1_p2 = _mm512_i64gather_epi64(addr_v1_p2, hash_t, scale);
vals_v0_p3 = _mm512_i64gather_epi64(addr_v0_p3, hash_t, scale);
vals_v1_p3 = _mm512_i64gather_epi64(addr_v1_p3, hash_t, scale);
vals_v0_p4 = _mm512_i64gather_epi64(addr_v0_p4, hash_t, scale);
vals_v1_p4 = _mm512_i64gather_epi64(addr_v1_p4, hash_t, scale);

mask_v0_p0 = _mm512_cmpeq_epi64_mask (vals_v0_p0, data_v0_p0);
mask_v1_p0 = _mm512_cmpeq_epi64_mask (vals_v1_p0, data_v1_p0);
mask_v0_p1 = _mm512_cmpeq_epi64_mask (vals_v0_p1, data_v0_p1);
mask_v1_p1 = _mm512_cmpeq_epi64_mask (vals_v1_p1, data_v1_p1);
mask_v0_p2 = _mm512_cmpeq_epi64_mask (vals_v0_p2, data_v0_p2);
mask_v1_p2 = _mm512_cmpeq_epi64_mask (vals_v1_p2, data_v1_p2);
mask_v0_p3 = _mm512_cmpeq_epi64_mask (vals_v0_p3, data_v0_p3);
mask_v1_p3 = _mm512_cmpeq_epi64_mask (vals_v1_p3, data_v1_p3);
mask_v0_p4 = _mm512_cmpeq_epi64_mask (vals_v0_p4, data_v0_p4);
mask_v1_p4 = _mm512_cmpeq_epi64_mask (vals_v1_p4, data_v1_p4);

ids_v0_p0 = _mm512_loadu_epi64(id + offset + 0);
ids_v1_p0 = _mm512_loadu_epi64(id + offset + 8);
ids_v0_p1 = _mm512_loadu_epi64(id + offset + 16);
ids_v1_p1 = _mm512_loadu_epi64(id + offset + 24);
ids_v0_p2 = _mm512_loadu_epi64(id + offset + 32);
ids_v1_p2 = _mm512_loadu_epi64(id + offset + 40);
ids_v0_p3 = _mm512_loadu_epi64(id + offset + 48);
ids_v1_p3 = _mm512_loadu_epi64(id + offset + 56);
ids_v0_p4 = _mm512_loadu_epi64(id + offset + 64);
ids_v1_p4 = _mm512_loadu_epi64(id + offset + 72);

_mm512_mask_compressstoreu_epi64(out_id + out_size, mask_v0_p0, ids_v0_p0);
out_size += _mm_popcnt_u64(mask_v0_p0);
_mm512_mask_compressstoreu_epi64(out_id + out_size, mask_v1_p0, ids_v1_p0);
out_size += _mm_popcnt_u64(mask_v1_p0);
_mm512_mask_compressstoreu_epi64(out_id + out_size, mask_v0_p1, ids_v0_p1);
out_size += _mm_popcnt_u64(mask_v0_p1);
_mm512_mask_compressstoreu_epi64(out_id + out_size, mask_v1_p1, ids_v1_p1);
out_size += _mm_popcnt_u64(mask_v1_p1);
_mm512_mask_compressstoreu_epi64(out_id + out_size, mask_v0_p2, ids_v0_p2);
out_size += _mm_popcnt_u64(mask_v0_p2);
_mm512_mask_compressstoreu_epi64(out_id + out_size, mask_v1_p2, ids_v1_p2);
out_size += _mm_popcnt_u64(mask_v1_p2);
_mm512_mask_compressstoreu_epi64(out_id + out_size, mask_v0_p3, ids_v0_p3);
out_size += _mm_popcnt_u64(mask_v0_p3);
_mm512_mask_compressstoreu_epi64(out_id + out_size, mask_v1_p3, ids_v1_p3);
out_size += _mm_popcnt_u64(mask_v1_p3);
_mm512_mask_compressstoreu_epi64(out_id + out_size, mask_v0_p4, ids_v0_p4);
out_size += _mm_popcnt_u64(mask_v0_p4);
_mm512_mask_compressstoreu_epi64(out_id + out_size, mask_v1_p4, ids_v1_p4);
out_size += _mm_popcnt_u64(mask_v1_p4);

offset += batch_size;
}
}
